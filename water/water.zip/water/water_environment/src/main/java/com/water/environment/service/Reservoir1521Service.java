package com.water.environment.service;

import com.alibaba.fastjson.JSONObject;

import java.util.Set;

public interface Reservoir1521Service {
    Set<JSONObject> select();
}
