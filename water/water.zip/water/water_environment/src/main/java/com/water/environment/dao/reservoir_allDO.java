package com.water.environment.dao;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "RESERVOIR_ALL")
public class reservoir_allDO extends ShipGraphDao {
}
