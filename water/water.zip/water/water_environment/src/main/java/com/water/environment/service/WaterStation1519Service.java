package com.water.environment.service;

import com.alibaba.fastjson.JSONObject;

import java.util.Set;

public interface WaterStation1519Service {
    Set<JSONObject> select();
}
