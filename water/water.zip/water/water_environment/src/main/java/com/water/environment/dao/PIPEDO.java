package com.water.environment.dao;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "PIPE")
public class PIPEDO extends ShipGraphDao {
}
