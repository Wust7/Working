package com.water.environment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WaterEnvironmentApplication {

    public static void main(String[] args) {
        SpringApplication.run(WaterEnvironmentApplication.class, args);
    }

}
