package com.water.environment.dao;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "POINT")
public class POINTDO extends ShipGraphDao {
}
