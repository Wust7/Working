package com.water.environment.dao;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "CONDUIT")
public class CONDUITDO extends ShipGraphDao {
}
