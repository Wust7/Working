# 进程被占用 查看进程pid ：netstat -ano | findstr 8888
# 中止进程 ： taskkill /F /pid 8888