package com.water.intrusion.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//海水入侵模块
@RestController
@RequestMapping("/intrusion")
public class WaterIntrusionController {

}
