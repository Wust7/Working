package com.water.intrusion.service;

import java.util.ArrayList;

public interface ParallelComputeService {

    ArrayList<ArrayList<ArrayList<String>>> get();
}
