package com.water.stormwaters;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WaterStormwatersApplication {

    public static void main(String[] args) {
        SpringApplication.run(WaterStormwatersApplication.class, args);
    }

}
