package com.water.stormwaters.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//雨虹模块
@RestController
@RequestMapping("/stormwaters")
public class WaterStormwatersController {

}
