package com.water.stormwaters;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WaterStormwatersApplicationTests {

    @Test
    void contextLoads() {
    }

}
